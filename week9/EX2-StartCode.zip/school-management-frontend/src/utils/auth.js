export function isAuthenticated() {
    // Implement your authentication logic here
}

export function setToken(token) {
    // implement your logic to set the token
}

export function logout() {
    // implement your logic to remove the token
}